package tests;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.*;
import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.util.*;
import java.util.concurrent.TimeUnit;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestExample {

    WebDriver driver;
    List<WebElement> elementList;
    int i = 0;
    private static final Logger logger = LogManager.getLogger(TestExample.class);

    @BeforeClass
    public void setUp() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        logger.info("Setting up the test...");
    }

    @Test
    public void testGoogleSearch() {
        driver.get("https://cinergyapp.thetunagroup.com/");
        implicitWait(15);
        driver.findElement(By.id("location_select")).click();
        driver.findElement(By.xpath("//option[text()='Charlotte, NC']")).click();
        driver.findElement(By.xpath("(//ul/li[1])[2]")).click();
        implicitWait(15);
        driver.findElement(By.xpath("//div[contains(@class,'calendar')]/div/i")).click();
        driver.findElement(By.xpath("//td[contains(@id,'14')]")).click();
        driver.findElement(By.xpath("//h3[contains(text(),'The Color')]")).click();
        driver.findElement(By.xpath("(//span[contains(text(),'3:20 PM')])[2]")).click();
        elementList = driver.findElements(By.xpath("//a[starts-with(@id, 'A-')]"));

        for (WebElement element : elementList) {
            element.click();
            i++;
            if (i == 4)
                break;
        }
        implicitWait(9);
        driver.findElement(By.xpath("//input[@id='voucher']")).sendKeys("Tet@123");
        driver.findElement(By.xpath("//button[contains(text(),'Appl')]")).click();
        for(int i=0;i<=3;i++)
            driver.findElement(By.xpath("(//img[contains(@src, 'plus')])[last()]")).click();
        driver.findElement(By.xpath("//input[@id='voucher']")).sendKeys("Tet@123");
        driver.findElement(By.xpath("//button[contains(text(),'Continue')]")).click();
        driver.findElement(By.xpath("//input[@id='PersonalFirstName']")).sendKeys("First");
        driver.findElement(By.xpath("//input[@id='PersonalLastName']")).sendKeys("Last");
        driver.findElement(By.xpath("//input[@id='PersonalEmail']")).sendKeys("fl@1.com");
        driver.findElement(By.xpath("//input[@id='PersonalPhone']")).sendKeys("9087654321");
        driver.findElement(By.xpath("//input[@id='zip']")).sendKeys("12345");


    }
    public void implicitWait(int time){
        driver.manage().timeouts().implicitlyWait(time, TimeUnit.SECONDS);
    }
    @AfterClass
    public void tearDown() {
        if (driver != null) {
            //driver.quit();
        }
        logger.info("Tear down...");
    }
}
